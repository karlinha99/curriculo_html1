Estrutura de Arquivos
┣ img
┃ ┣ WhatsApp.png
┃ ┣ icon.png
┃ ┣ linkedin.png
┃ ┣ mail.png
┃ ┗ perfil.png
┣ README.md
┣ index.html
┗ styles.css